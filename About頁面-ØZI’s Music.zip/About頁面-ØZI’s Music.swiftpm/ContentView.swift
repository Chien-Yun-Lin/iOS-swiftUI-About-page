import SwiftUI

struct Album: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
    let tracks: [String]
}

struct Single: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
}

struct SectionTitleView: View {
    let text: String
    var body: some View {
        HStack {
            Text(text)
                .font(.title2)
                .fontWeight(.bold)
                .padding(.leading, 16)
            Spacer()
        }
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
    }
}

struct AlbumCardView: View {
    let album: Album
    @Binding var pressedAlbumID: UUID?
    
    var body: some View {
        VStack {
            Image(album.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 160, height: 160)
                .cornerRadius(12)
                .shadow(radius: 6)
                .scaleEffect(pressedAlbumID == album.id ? 0.93 : 1.0)
                .animation(.easeInOut(duration: 0.2), value: pressedAlbumID)
            
            Text(album.title)
                .font(.caption)
                .lineLimit(1)
                .foregroundColor(.primary)
        }
    }
}

struct SingleCardView: View {
    let single: Single
    @Binding var pressedSingleID: UUID?
    
    var body: some View {
        VStack(spacing: 8) {
            Image(single.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 140, height: 140)
                .clipped()
                .cornerRadius(12)
                .shadow(radius: 6)
                .scaleEffect(pressedSingleID == single.id ? 0.93 : 1.0)
                .animation(.easeInOut(duration: 0.2), value: pressedSingleID)
            Text(single.title)
                .font(.caption)
                .multilineTextAlignment(.center)
                .foregroundColor(.primary)
                .frame(width: 140)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 4)
        .frame(width: 140)
    }
}

struct AlbumSection: View {
    let title: String
    let albums: [Album]
    @State private var pressedAlbumID: UUID? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitleView(text: title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 18) {
                    ForEach(albums) { album in
                        NavigationLink(destination: AlbumDetailView(album: album)) {
                            AlbumCardView(album: album, pressedAlbumID: $pressedAlbumID)
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0)
                            .onChanged { _ in pressedAlbumID = album.id }
                            .onEnded { _ in
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    pressedAlbumID = nil
                                }
                            }
                        )
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

struct SinglesSection: View {
    let title: String
    let singles: [Single]
    @State private var pressedSingleID: UUID? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitleView(text: title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(alignment: .top, spacing: 18) {
                    ForEach(singles.prefix(6)) { single in
                        SingleCardView(single: single, pressedSingleID: $pressedSingleID)
                            .simultaneousGesture(DragGesture(minimumDistance: 0)
                                .onChanged { _ in pressedSingleID = single.id }
                                .onEnded { _ in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        pressedSingleID = nil
                                    }
                                }
                            )
                    }

                    NavigationLink(destination: SingleDetailView(singles: singles)) {
                        VStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(width: 140, height: 140)
                                    .overlay(
                                        Image(systemName: "chevron.right")
                                            .font(.largeTitle)
                                            .foregroundColor(.blue)
                                    )
                            }
                            Text("More")
                                .font(.caption)
                                .foregroundColor(.primary)
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal)
            }
        }
    }
}

struct AlbumDetailView: View {
    let album: Album
    
    var body: some View {
        List {
            Section(header:
                        HStack {
                Image(systemName: "music.note.list")
                    .foregroundColor(.blue)
                Text(album.title)
                    .font(.title3)
                    .fontWeight(.bold)
            }
            ) {
                ForEach(album.tracks, id: \.self) { track in
                    HStack {
                        Text(track)
                        Spacer()
                        Image(systemName: "play.fill")
                            .foregroundColor(.blue)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
        .navigationTitle(album.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SingleDetailView: View {
    let singles: [Single]
    
    var body: some View {
        List {
            Section(header:
                        HStack {
                Image(systemName: "music.note")
                    .foregroundColor(.blue)
                Text("Singles")
                    .font(.title3)
                    .fontWeight(.bold)
            }
            ) {
                ForEach(singles) { single in
                    HStack {
                        Image(single.imageName)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 50, height: 50)
                            .cornerRadius(6)
                            .shadow(radius: 3)
                        
                        Text(single.title)
                            .font(.body)
                            .lineLimit(nil)
                        
                        Spacer()
                        
                        Image(systemName: "play.fill")
                            .foregroundColor(.blue)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
        .navigationTitle("Singles")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct AwardsSection: View {
    let awards: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitleView(text: "Awards")
            
            ForEach(awards, id: \.self) { award in
                HStack {
                    Image(systemName: "rosette")
                        .foregroundColor(.orange)
                    Text(award)
                }
                .padding(.horizontal)
            }
        }
    }
}

struct MerchSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitleView(text: "Merch")
            
            if let url = URL(string: "https://www.instagram.com/ozymaniac?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==") {
                Link(destination: url) {
                    Image("Maniac")
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(12)
                        .shadow(radius: 6)
                        .padding(.horizontal)
                }
                .buttonStyle(PlainButtonStyle())
            } else {
                Image("MerchImage")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(12)
                    .shadow(radius: 6)
                    .padding(.horizontal)
            }
        }
    }
}

struct SocialLinksSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Follow ØZI")
                .font(.title2)
                .fontWeight(.semibold)
                .padding(.horizontal)
            
            HStack(spacing: 40) {
                SocialButton(icon: "camera", label: "Instagram", urlString: "https://www.instagram.com/ozifp/")
                SocialButton(icon: "video", label: "YouTube", urlString: "https://youtube.com/@ozifp?si=z3C1VbiKtkp6W2Gf")
                SocialButton(icon: "music.note", label: "Apple Music", urlString: "https://music.apple.com/tw/artist/%C3%B8zi/1316963118")
            }
            .padding(.horizontal)
        }
        .padding(.bottom, 40)
    }
}

struct SocialButton: View {
    let icon: String
    let label: String
    let urlString: String
    
    @State private var isPressed = false
    
    private var backgroundGradient: LinearGradient {
        let lower = label.lowercased()
        if lower.contains("instagram") {
            return LinearGradient(
                colors: [
                    Color(red: 0.60, green: 0.20, blue: 0.80) ,
                    Color(red: 0.960, green: 0.521, blue: 0.161),
                    Color(red: 0.98, green: 0.18, blue: 0.38) 
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else if lower.contains("youtube") {
            return LinearGradient(
                colors: [
                    Color(red: 0.91, green: 0.12, blue: 0.2),
                    Color(red: 0.78, green: 0.08, blue: 0.14)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
        } else if lower.contains("apple") || lower.contains("music") {
            return LinearGradient(
                colors: [
                    Color(red: 0.45, green: 0.18, blue: 0.84),
                    Color(red: 0.96, green: 0.36, blue: 0.76)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(colors: [Color.gray.opacity(0.2), Color.gray.opacity(0.15)], startPoint: .top, endPoint: .bottom)
        }
    }
    
    var body: some View {
        if let url = URL(string: urlString) {
            Link(destination: url) {
                VStack(spacing: 6) {
                    ZStack {
                        Circle()
                            .fill(backgroundGradient)
                            .frame(width: 56, height: 56)
                            .shadow(color: .black.opacity(0.18), radius: 4, x: 0, y: 2)
                        Image(systemName: icon)
                            .font(.title2)
                            .foregroundColor(.white) 
                    }
                    .scaleEffect(isPressed ? 0.85 : 1.0)
                    .animation(.spring(response: 0.32, dampingFraction: 0.6), value: isPressed)
                    
                    Text(label)
                        .font(.caption)
                        .foregroundColor(.primary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(PlainButtonStyle())
            .simultaneousGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        withAnimation(.spring(response: 0.2, dampingFraction: 0.6)) {
                            isPressed = true
                        }
                    }
                    .onEnded { _ in
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                            withAnimation(.spring(response: 0.24, dampingFraction: 0.6)) {
                                isPressed = false
                            }
                        }
                    }
            )
        } else {
            VStack(spacing: 6) {
                ZStack {
                    Circle()
                        .fill(backgroundGradient)
                        .frame(width: 56, height: 56)
                        .shadow(color: .black.opacity(0.18), radius: 4, x: 0, y: 2)
                    Image(systemName: icon)
                        .font(.title2)
                        .foregroundColor(.white)
                }
                Text(label)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .opacity(0.9)
        }
    }
}

struct ContentView: View {
    let albums: [Album] = [
        Album(title: "ØZI：The Album", imageName: "Album1", tracks: [
            "Øzymandias (Intro)", "Diamond", "Paradise Island", "We Out Here",
            "Black Out (feat. 9m88)", "Wings", "Me Instead", "Bad Intensions",
            "Prey", "Title"
        ]),
        Album(title: "PEDESTAL", imageName: "Album2", tracks: [
            "PEDESTAL", "LUFU (feat. Arin Ray & GSoul)", "Slide", "0.03",
            "LAVA!", "Just Do You (feat. sunkis 宋秉勤)", "Missionary", "Free Fall"
        ]),
        Album(title: "ADICA", imageName: "Album3", tracks: [
            "Come Alive", "ADICA", "Issues", "Not In The Mood", "Avant-Garde", "Memos"
        ]),
        Album(title: "Swirl", imageName: "Album4", tracks: [
            "Swirl: Editor’s Notes", "Effortless (feat. Jay Park, GroovyRoom)",
            "EEEASY (feat. 艾志恆 Asen)", "Sex Tape (feat. 落日飛車 Sunset Rollercoaster)",
            "Bad Sign", "Bleu (feat. 9m88)", "Re-Up (feat. Karencici)",
            "PRE55URE (feat. JP The Wavy, Awich, MFS)",
            "Final Final Final (feat. The Crane, Gummy B)"
        ])
    ]
    
    let singles: [Single] = [
        Single(title: "Love You Right", imageName: "Single1"),
        Single(title: "走到飛 (feat. 呂士軒、吳卓源、熊仔、BCW、Barry Chen & 大支)", imageName: "Single2"),
        Single(title: "Ootd (feat. RayRay)", imageName: "Single3"),
        Single(title: "If Only…", imageName: "Single4"),
        Single(title: "滾床單 (feat. SJIN)", imageName: "Single18"),
        Single(title: "S.M.O.K.E. 狼煙 (feat. KENZY 小春)", imageName: "Single5"),
        Single(title: "Who’s Next?", imageName: "Single6"),
        Single(title: "Go Ahead", imageName: "Single7"),
        Single(title: "hair tie", imageName: "Single8"),
        Single(title: "DEATH TRIP (feat. 蛋堡)", imageName: "Single9"),
        Single(title: "曖 (feat. 孫盛希)", imageName: "Single16"),
        Single(title: "House Party (feat. 家家)", imageName: "Single14"),
        Single(title: "站出來 (feat. 王Aden)", imageName: "Single17"),
        Single(title: "U sTuPid (feat. Karencici)", imageName: "Single15"),
        Single(title: "BITE (feat. Karencici)", imageName: "Single11"),
        Single(title: "ICE AND FIRE", imageName: "Single10"),
        Single(title: "HEAT", imageName: "Single12"),
        Single(title: "情勒 Gaslight (feat. Marz23)", imageName: "Single19"),
        Single(title: "妳在哪裡 Remix (feat. 朴宰範 & NingNing, pH-1, 劉柏辛 Lexie, 馬思唯)", imageName: "Single20"),
        Single(title: "Paranoia - heartsteel, League of Legends (feat. Tobi Lou, Cal Scruby & Baekhyun)", imageName: "Single21")
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    
                    ZStack(alignment: .bottomLeading) {
                        Image("ØZI")
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(16)
                            .shadow(radius: 8)
                        
                        Text("ØZI")
                            .font(.largeTitle)
                            .fontWeight(.heavy)
                            .foregroundColor(.white)
                            .padding()
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("About ØZI")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Text("""
ØZI出道便以首張專輯《ØZI: The Album》驚豔樂壇，一舉入圍2019年金曲獎「最佳國語男歌手獎」、「最佳國語專輯獎」、「最佳編曲人獎」、「最佳單曲製作人獎」、「最佳新人獎」和「年度專輯獎」，最終獲得「最佳新人獎」。藝名「ØZI」取自雪萊詩作《Ozymandias》，亦源於古埃及法老拉美西斯二世的希臘名字，象徵其音樂抱負。
本名陳奕凡的ØZI，1997年出生於洛杉磯，兩歲返台，就讀雙語學校與台北美國學校。承襲歌手母親葉璦菱與攝影師父親陳文彬的藝術基因，自幼學習多種樂器，十四歲開始創作英文歌曲。東西方生活經驗讓他同時吸收西洋與華語音樂影響，從LINKIN PARK、艾薇兒到周杰倫皆啟發了他，使其作品能融合搖滾、電音、R&B與嘻哈元素。
ØZI曾獲JYP娛樂邀約，但選擇獨立發展。2015年起自製音樂上傳網路，2017年與剃刀蔣、米奇林 MCKY 創立廠牌「新樂園 Forbidden Paradise」，推廣台灣R&B。〈頭銜〉與〈奪愛〉打開知名度，〈天堂島〉更突破百萬點擊，展現其音樂與影像創作才華。《ØZI: The Album》後，他於2020年與Transparent Arts合作，拓展國際市場。2021 年專輯《PEDESTAL》展現性感神祕的 R&B 風格，2023 年 EP《ADICA》融入金屬與Grunge，彰顯獨特品味與跨界能量，以國際視野打造屬於自己的音樂王國。
""")
                        .font(.body)
                        .foregroundColor(.secondary)
                        .lineSpacing(6)
                    }
                    .padding(.horizontal)
                    AlbumSection(title: "Albums", albums: albums)
                    SinglesSection(title: "Singles", singles: singles)
                    AwardsSection(awards: [
                        "中華音樂人交流協會 2017年度十大單曲 <走到飛>",
                        "中華音樂人交流協會 2018年度十大專輯 《ØZI: The Album》",
                        "HitFm 2018年度十大專輯 《ØZI: The Album》",
                        "Hito流行音樂獎 HitFm 2019 DJ最愛點播單曲 <B.O. (feat. 9m88)>",
                        "唱工委音樂獎 2019 最佳說唱專輯《ØZI: The Album》",
                        "金音創作獎 2019 最佳節奏藍調專輯 《ØZI: The Album》",
                        "Freshmusic Awards 2019 最佳新人",
                        "金曲獎 2019 最佳新人獎",
                        "中華音樂人交流協會 2021年度十大單曲 <DEATH TRIP (feat. 蛋堡)>",
                        "Lavender Music Awards 2025 十大年度歌曲 <Bleu (feat. 9m88)>",
                        "Lavender Music Awards 2025 最佳編曲人獎 <Sex Tape (feat. 落日飛車)>",
                        "Lavender Music Awards 2025 最佳演唱組合歌曲獎 <Bleu (feat. 9m88)>"
                    ])
                    MerchSection()
                    SocialLinksSection()
                }
                .padding(.vertical)
            }
            .navigationTitle("Artist")
        }
    }
}
